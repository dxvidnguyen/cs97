/*header file output.h*/
bool writebytes (unsigned long long x, int nbytes);
