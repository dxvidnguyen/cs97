
/* header file rand64-sw.h*/
void initfile (char* file);
void software_rand64_init (void);
unsigned long long software_rand64 (void);
void software_rand64_fini (void);
