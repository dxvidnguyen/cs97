#!/bin/bash
git diff $1..$2
