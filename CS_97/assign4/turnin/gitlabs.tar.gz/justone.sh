#!/bin/bash
git diff HEAD^!
